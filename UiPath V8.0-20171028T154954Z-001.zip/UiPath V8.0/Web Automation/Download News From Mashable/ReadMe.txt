Task:

Use the following site mashable.com to download 3 news from the category you choose.

Steps:

1.Choose a category from the list or "None".

2.If the user chose a news category then open the website (mashable.com/Category/).

3.Otherwise, if the user chose "None" , display a friendly message.

4.After the website is open extract the news title and the URL than close the tab.

5.For each news open the link and extract the content (without photos) and put it in a text document.
In the text document must be the title and the content of each news.

6.After that you should come back and display all the news category , maybe the user want to choose another one.


