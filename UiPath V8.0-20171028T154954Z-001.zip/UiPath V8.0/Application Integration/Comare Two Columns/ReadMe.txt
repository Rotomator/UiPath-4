Task:
Compare two columns in Excel and write in the third column:
"=" if the numbers are equal.
"a" if the first number is greater.
"b" if the secound number is greater.

Solution:

Steps:
 
1. Read Excel file.

2. Use a "For each row in a DataTable " structure.

3. In the Body section we will use a "if" to determin if the numbers are equal.

4. If the previos condition is not tre we need another "if" to determin wich number is greater.

5. In the Main we need a variable that increases at each step.
