This sample extracts a value from calculator application in a remote desktop when a button is clicked. The value extracted will be written in Output pane

Steps

1. Add an "On Click Image" event and bound it to the "=" image from the calculator app
2. Add 2 click image events: for "Edit" and "Copy"
3. Add a Get from clipboard activity
