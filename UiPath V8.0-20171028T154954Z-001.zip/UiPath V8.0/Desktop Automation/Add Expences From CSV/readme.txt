Task

Automate data entry in an application from a CSV file

Steps

1. Read CSV file
2. Open the expenseit application
3. Record add expense sequence within expenseit app 
4. Create a "foreach row in datatable" activity
5. Move the previous recorded sequence inside it and replace the hardcoded data with data from the datatable
6. Click OK to save the modifications
7. Close the expenseit app.
